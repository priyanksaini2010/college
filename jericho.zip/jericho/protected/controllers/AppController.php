<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of API
 *
 * @author e3020706
 */
ob_start();
class AppController extends Controller{
    //put your code here
    
    private $session;


    public function actions()
    {
        return array(
                // captcha action renders the CAPTCHA image displayed on the contact page
                'captcha'=>array(
                        'class'=>'CCaptchaAction',
                        'backColor'=>0xFFFFFF,
                ),
                // page action renders "static" pages stored under 'protected/views/site/pages'
                // They can be accessed via: index.php?r=site/page&view=FileName
                'page'=>array(
                        'class'=>'CViewAction',
                ),
        );
    }
    public static function auth(){
        if(isset($_POST['device_token']) && isset($_POST['device_id']) && isset($_POST['session_id'])) {
            $attributes = array(
                                    "device_token" => $_POST['device_token'],
                                    "device_id" => $_POST['device_id'],
                                    "session_id" => $_POST['session_id'],
                                );
            $session = Sessions::model()->findByAttributes($attributes);
            if(!empty($session)) {
                if($session->is_expired == 1) {
                    sendResponse(array("failure","Session Expired",""));
                } else{
                    return $session;
                }
            } else {
                return  self::authenticateRequestBase();
            }
        } else {
            sendResponse(array("failure","Invalid Request",""));
        }
    }
    
//     && isset($_POST['device_token']) && isset($_POST['device_id']) && isset($_POST['session_id'])
    private static function authenticateRequestBase(){
        if(!empty($_POST)){
            if(isset($_POST['salt']) && isset($_POST['device_id'])){
                if($_POST['salt'] != Yii::app()->params->secret_key) {
                    sendResponse(array("failure","Invalid Request, Salt doesnot match",""));
                } else {
                    $sessionCreator = new Sessions;
                    $attribs = array(
                                    'device_token' => stringGen(),
                                    'device_id' => $_POST['device_id'],
                                    'session_id' => randomSessionId(10,1,"numbers"),
                                    'start_time' => date("Y-m-d h:i:s"),
                                    'is_expired' => 0,
                                );
                    $sessionCreator->attributes = $attribs;
                    if($sessionCreator->save()) {
                        return $attribs;
                    } else {
                        sendResponse(array("failure","unable to create session.",""));
                    }
                }
            } else {
                sendResponse(array("failure","Invalid Request, Salt is missing",""));
            }
        } else {
            sendResponse(array("failure","Invalid Request",""));
        }
    }
    private function authenticateRequestContinous(){
        if(!empty($_POST)){
            
        } else {
            sendResponse(array("failure","Invalid Request",""));
        }
    }


    public function actionLogin(){
        if(!empty($_POST)){
            $session = $this->session = self::auth();
            if(isset($_POST['userid']) && isset($_POST['password'])){
                $attribs = array(
                                    "userid"=>$_POST['userid'],
                                    "password"=>$_POST['password'],
                                );
                $authentication = Customers::model()->findByAttributes($attribs);
                if(!empty($authentication)){
                    $response = array(
                                    "userid" => $authentication->userid,
                                    "customer_name" => ucfirst($authentication->name),
                                    "acct_num" => $authentication->account_number,
                                );
                    sendResponse(array("success","",$response),$session);
                } else {
                    sendResponse(array("failure","UserId or Password is wrong.'",""));
                }
            } else  {
                sendResponse(array("failure","UserId or Password is missing.'",""));
            }
        }
        sendResponse(array("failure","Invalid Request",""));
        
    }
    
    public function actionTask(){
        if(!empty($_POST)){
            $session = $this->session = self::auth();
            if(isset($_POST['task'])){
                $task = $this->identifyTask($_POST['task']);
                if($task != "not_found"){
                    switch($task){
                        case "show_balance":
                                $this->showbalance($_POST['userid']);
                            break;
                        case "transfer":
                                $this->processTransferRequest($_POST['task'],$_POST['userid']);
                            break;
                        case "last_tr":
                                $this->showLastTr($_POST['userid']);
                            break;
                    }
                } else{
                    sendResponse(array("failure","Unable to identify task",""),$session);
                }
            } else {
                sendResponse(array("failure","Task not defined",""),$session);
            }
        }
        sendResponse(array("failure","Unable to recognize task",""),  $this->session);
    }
    
    private function showLastTr($userid){
        preg_match_all('!\d+!', $_POST['task'], $matches);
        $lim = 1;
        if(isset($matches[0][0]) && $matches[0][0]){
            $lim = $matches[0][0];
        } else {
            $result=preg_match_all('/(?<=(last))(\s\w*)/',$_POST['task'],$matches);
            $amount = "";
            if(isset($matches[0][0]) && $matches[0][0]){
                $amount = wordsToNumber(trim($matches[0][0]));
            }
            if($amount != "") {
                $lim =  $amount;
            }
        }
        $custDetails = Customers::model()->findByAttributes(array("userid"=>$userid));
        $criteria=new CDbCriteria;
        $criteria->order='id DESC';
        $criteria->limit=$lim;
        $criteria->compare('customer_id_payer',$custDetails->id);
        $models = CustomerTransaction::model()->findAll($criteria);
        $message = "";
        foreach ($models as $mod){
            $message .= $mod->transaction_description." . ";
        }
        sendResponse(array("success","","2"=>array("acct_balance_num"=>$message)),  $this->session);
    }
    public function actionCompleteTransaction(){
        if(!empty($_POST)){
            $session = $this->session = self::auth();
            if(isset($_POST['transaction_id']) && isset($_POST['challenge_question'])) {
                $txDetails = CustomerTransaction::model()->findByAttributes(array("transaction_id"=>$_POST['transaction_id'],"is_completed"=>0));
                if(!empty($txDetails)){
                    $challenge_question = $_POST['challenge_question'];
                    if(!empty($challenge_question)){
                        $tx = CustomerTransaction::model()->findByPk($txDetails->id);
                        $payerTx = Customers::model()->findByPk($tx->customer_id_payer);
                        $payeeTx = Customers::model()->findByPk($tx->customer_id_payee);
                        $payerTx->attributes = array(
                                    "balance" => ($payerTx->balance - $tx->amount),
                        );
                        $payeeTx->attributes = array(
                                    "balance" => ($payeeTx->balance + $tx->amount),
                        );
                        if($payeeTx->save() && $payerTx->save()){
                            $tx->attributes = array("is_completed" => 1);
                            if($tx->save()){
                                sendResponse(array("success","Funds Transfered successfully",""),  $this->session);
                            } else {
                                sendResponse(array("success","Transaction not updated",""),  $this->session);
                            }
                        } else {
                            sendResponse(array("failure","Unable to send funds",""),  $this->session);
                        }
                    } else {
                        sendResponse(array("failure","Unable to send funds",""),  $this->session);
                    }
                } else {
                    sendResponse(array("failure","Invalid Transaction",""),  $this->session);
                }
            } else {
                sendResponse(array("failure","Invalid Request",""),  $this->session);
            }
        } else {
            sendResponse(array("failure","Invalid Request",""),  $this->session);
        }
    }
    
    
    
    private function identifyTask($task){
        
        if (preg_match("/\bbalance\b/i", $task)) {
            return "show_balance";
        }else if (preg_match("/\bfunds\b/i", $task)) {
            return "show_balance";
        }
        else if (preg_match("/\btransaction\b/i", $task)) {
            return "last_tr";
        }else if (preg_match("/\blast\b/i", $task)) {
            return "last_tr";
        }else if (preg_match("/\btime\b/i", $task)) {
            return "last_tr";
        }
        else if (preg_match("/\bamount\b/i", $task)) {
            return "show_balance";
        }else if (preg_match("/\bspend\b/i", $task)) {
            return "show_balance";
        }else if (preg_match("/\bshow\b/i", $task)) {
            if (preg_match("/\bfund\b/i", $task)) {
                return "show_balance";
            } else if(preg_match("/\bpayee\b/i", $task)){
                return "show_payee";
            }
            
        }else if (preg_match("/\bhow\b/i", $task)) {
            if (preg_match("/\bmuch\b/i", $task)) {
                if (preg_match("/\bmoney\b/i", $task)) {
                    return "show_balance";
                } 
            }
            return "not_found";
        }else if (preg_match("/\bmoney\b/i", $task)) {
            return "show_balance";
        }
        else if(preg_match("/\btransfer\b/i", $task)) {
            return "transfer";
        }else if(preg_match("/\bsend\b/i", $task)) {
            return "transfer";
        }else if(preg_match("/\btransaction\b/i", $task)) {
            return "last_tr";
        }else if(preg_match("/\btime\b/i", $task)) {
            return "last_tr";
        }
        else{
            return "not_found";
        }
    }
    
    private function processTransferRequest($task, $userid){
        $payee = $this->identifyPayee($task);
        $amount = $this->identifyAmount($task);
        if($payee != "" && $amount != ""){
            $payerDetails = Customers::model()->findByAttributes(
                                                                array("userid" => $userid)
                                                            );
            if(!empty($payerDetails)) {
                if($payerDetails->balance >= $amount) {
                    $payeeDetails = CustomerPayee::model()
                                        ->findByAttributes(
                                                    array(
                                                            "nick_name"=>$payee,
                                                            "customer_id"=>$payerDetails->id,
                                                        ));
                    if(!empty($payeeDetails)) {
                        $transaction = new CustomerTransaction;
                        $attributes = array(
                                                'customer_id_payer' => $payerDetails->id,
                                                'customer_id_payee' => $payeeDetails->payee_customer_id,
                                                'transaction_id' => randomSessionId(10,1,"numbers"),
                                                'amount' => $amount,
                                                'transaction_date' => date("Y-m-d h:i:s"),
                                                'transaction_description' => "You have sent ".$amount ." dollars to ".$payee." on ".date("dS, F Y"),
                                                'is_completed' => 0,
                                            );
                        $transaction->attributes = $attributes;
                        if($transaction->save()) {
                            $challengeQuestions = CustomerChallengeQuestion::model()->findAllByAttributes(array("customer_id" =>$payerDetails->id));
                            if(!empty($challengeQuestions)) {
                                $question = array();
                                foreach ($challengeQuestions as $challengeQuestion){
                                    $question[$challengeQuestion->id] = $challengeQuestion->challenge_question;
                                    break;
                                }
                                $txDetails = CustomerTransaction::model()->findByAttributes(array("transaction_id"=>$transaction->attributes['transaction_id'],"is_completed"=>0));
                                $tx = CustomerTransaction::model()->findByPk($txDetails->id);
                                $payerTx = Customers::model()->findByPk($tx->customer_id_payer);
                                $payeeTx = Customers::model()->findByPk($tx->customer_id_payee);
                                $payerTx->attributes = array(
                                            "balance" => ($payerTx->balance - $tx->amount),
                                );
                                $payeeTx->attributes = array(
                                            "balance" => ($payeeTx->balance + $tx->amount),
                                );
                                if($payeeTx->save() && $payerTx->save()){
                                    $tx->attributes = array("is_completed" => 1);
                                    if($tx->save()){
                                        $message = "Funds have been transfered successfully to ".$payee.""
                                                . " Your updated balance is ".($payerTx->balance - $tx->amount)." dollars";
                                        sendResponse(array("success","Funds Transfered successfully","2"=>array("acct_balance_num"=>$message)),  $this->session);
                                    } else {
                                        sendResponse(array("success","Transaction not updated",""),  $this->session);
                                    }
                                } else {
                                    sendResponse(array("failure","Unable to send funds",""),  $this->session);
                                }
                                sendResponse(array("success","",2=>array("challenge_question"=>$question,"transaction_id" => $attributes['transaction_id'])),  $this->session);
                            } else {
                                sendResponse(array("failure","Unable to send funds",""),  $this->session);
                            }
                        } else {
                            sendResponse(array("failure","Unable to send funds",""),  $this->session);
                        }
                    } else {
                        sendResponse(array("failure","You have not added ".$payee." as payee.",""),  $this->session);
                    }
                    
                } else {
                    sendResponse(array("failure","You dont have sufficient funds in your account",""),  $this->session);
                }
                
            } else{
                sendResponse(array("failure","Customer Not Found",""),  $this->session);
            }
            
        }
        sendResponse(array("success","","Transfering ".$amount." to ".$payee),  $this->session);
    }
    
    private function identifyPayee($task){
        $result=preg_match_all('/(?<=(to))(\s\w*)/',$task,$matches);
        
        if(count($matches)>1){
            if(isset($matches[0][0]) && !empty($matches[0][0])){
                return trim($matches[0][0]);
            }else {
                sendResponse(array("failure","","Not able to recognize payee"),  $this->session);
            }
        }
    }
    
    private function identifyAmount($task){
        
        preg_match_all('!\d+!', $task, $matches);
        if(isset($matches[0][0]) && $matches[0][0]){
            return $matches[0][0];
        } else {
            $amount = $this->identifyAlphaAmount($task);
            if($amount != "") {
                return $amount;
            }
            sendResponse(array("failure","","Not able to recognize amount."),  $this->session);
        }
    }
    
    private function identifyAlphaAmount($task){
        // getting multiplier
        $multiplier = 1;
        if(preg_match("/\bthousand\b/i", $task)) {
            $multiplier = 1000;
        }
        else if(preg_match("/\bhundred\b/i", $task)){
            $multiplier = 100;
        } 
        else if(preg_match("/\bmillion\b/i", $task)){
            $multiplier = 1000000;
        } 
        $digit = $this->identifyDigit($task, $multiplier);
        
        if($digit != "" && $multiplier != "") {
            return $digit * $multiplier;
        }
        sendResponse(array("failure","","Not able to recognize amount."),  $this->session);
    }

    private function identifyDigit($task, $multiplier){
        $digit = "";
        switch ($multiplier){
            case 100:
                preg_match("/(\w+) hundred (\w+)/mu", $task, $matches);
                
                break;
            case 1000:
                $re = '/((\w* ){0,5})(thousand)(( \w*){0,5})/i'; 
                preg_match_all($re, $task, $matches);
                
                break;
            case 1000000:
                preg_match("/(\w+) million (\w+)/mu", $task, $matches);
                
                break;
        }
        $digit = isset($matches[2][0])?$matches[2][0]:"";
        if($digit != "") {
            $num = wordsToNumber($digit);
            if($num != ""){
                return $num;
            } else {
                sendResponse(array("failure","","Not able to recognize amount."),  $this->session);
            }
        } else{
            sendResponse(array("failure","","Not able to recognize amount."),  $this->session);
        }
    }
    private function showbalance($userid){
        $data = Customers::model()->findByAttributes(array("userid"=>$userid));
        if(!empty($data)){
            sendResponse(array("success","","2"=>array("acct_balance_num"=>  "You have ".ceil($data->balance)." dollars in your account.","acct_balance_spell"=> "You have ". convertNumberToWord(ceil($data->balance))." dollars in your account.") ),  $this->session);
        } else {
            sendResponse(array("failure","Unable to find customer",""),$this->session);
        }
        
    }
}
