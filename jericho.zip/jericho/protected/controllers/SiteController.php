<?php
ob_start();
class SiteController extends Controller
{
        public $errors = array();
        public $success = array();
	/**
	 * Declares class-based actions.
	 */
	public function actions()
	{
		return array(
			// captcha action renders the CAPTCHA image displayed on the contact page
			'captcha'=>array(
				'class'=>'CCaptchaAction',
				'backColor'=>0xFFFFFF,
			),
			// page action renders "static" pages stored under 'protected/views/site/pages'
			// They can be accessed via: index.php?r=site/page&view=FileName
			'page'=>array(
				'class'=>'CViewAction',
			),
		);
	}

	/**
	 * This is the default 'index' action that is invoked
	 * when an action is not explicitly requested by users.
	 */
	public function actionIndex()
	{
            $this->layout = 'login';
            $this->pageTitle = "Home";
            $model=new LoginForm;

		// if it is ajax validation request
		if(isset($_POST['ajax']) && $_POST['ajax']==='login-form')
		{
			echo CActiveForm::validate($model);
			Yii::app()->end();
		}

		// collect user input data
               
		if(isset($_POST['LoginForm']))
		{
                        
			$model->attributes=$_POST['LoginForm'];
			// validate user input and redirect to the previous page if valid
			if($model->validate() && $model->login()){
                            $this->redirect(Yii::app()->createUrl("site/dashboard"));
                        } else {
                            foreach($model->getErrors() as $key=>$errors){
                                $this->errors[$key]  = $errors[0];
                            }
                        } 
		}
		// renders the view file 'protected/views/site/index.php'
		// using the default layout 'protected/views/layouts/main.php'
            $this->render('login',array('model'=>$model));
	}
        
        /**
         * Register Industry/Institute
         */
	public function actionDashboard()
	{
           $debit_data = array(
                    'Current Balance' => 15000,
                    'Demat' => 0.0,
                    'Deposits' => 0.0
           );
           $credit_data = array(
                    'Credit Cards' => 15000,
                    'Loans' => 0.0,
                    'Insurance' => 0.0
           );
            
            $this->render('dashboard', array('debit_data' => $debit_data,'credit_data'=> $credit_data));
	}
        public function actionChequeGenerate(){
            $model=new GenerateChequeForm;
            // if it is ajax validation request
		if(isset($_POST['ajax']) && $_POST['ajax']==='cheque-form')
		{
			echo CActiveForm::validate($model);
			Yii::app()->end();
		}
               
                if(!empty($_POST) && !isset($_POST['GenerateChequeForm'])) {
                    
                    $ch = curl_init();
                    curl_setopt($ch, CURLOPT_URL,"http://del1-lp-23n0cg2/GenerateCheckAPI/api/getCheck/GetCheckImage");
                    curl_setopt($ch, CURLOPT_POST, 1);
                    curl_setopt($ch, CURLOPT_POSTFIELDS,
                                "UserID=".$_POST['token']."&OTPToken=".$_POST['otp']);
                   

                    // in real life you should use something like:
                    // curl_setopt($ch, CURLOPT_POSTFIELDS, 
                    //          http_build_query(array('postvar1' => 'value1')));

                    // receive server response ...
                    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

                    $server_output = curl_exec ($ch);

                    curl_close ($ch);
                    //$name = rand().'--'.  base64_encode(json_encode($_POST['cheque_data'])).'.jpeg';
                    file_put_contents("assets/".$_POST['cheque_data'], base64_decode($server_output));
                    $url  =  '\assets';
                    $this->render('display_cheque',array('cheque'=> json_decode($server_output),"url"=>$url.'\\'.$_POST['cheque_data'],"name"=>$_POST['cheque_data']));
                    //$this->render('otp_verification',array('cheque_data'=> $name));
                    exit();
                }
                if(isset($_POST['GenerateChequeForm'])){
                    
                    $ch = curl_init();
                    curl_setopt($ch, CURLOPT_URL,"http://del1-lp-23n0cg2/GenerateCheckAPI/api/getCheck/sendOTP");
                    curl_setopt($ch, CURLOPT_POST, 1);
                    curl_setopt($ch, CURLOPT_POSTFIELDS,
                                "UserID=".$_POST['GenerateChequeForm']['token']."&Amount=".$_POST['GenerateChequeForm']['amount']."&IssueDate=".$_POST['GenerateChequeForm']['date']."&Payee=".$_POST['GenerateChequeForm']['accountName']);
                    $str = array("UserID"=>$_POST['GenerateChequeForm']['token'],
                            "Amount"=>$_POST['GenerateChequeForm']['amount'],
                            "IssueDate"=>$_POST['GenerateChequeForm']['date'],
                            "Payee"=>$_POST['GenerateChequeForm']['accountName']);

                    // in real life you should use something like:
                    // curl_setopt($ch, CURLOPT_POSTFIELDS, 
                    //          http_build_query(array('postvar1' => 'value1')));

                    // receive server response ...
                    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

                    $server_output = curl_exec ($ch);

                    curl_close ($ch);
                    //pr($server_output);die;
//                    pr(json_decode($server_output));
//                    echo " <img src='data:image/jpeg;base64, ".json_decode($server_output)."' alt='Red dot' />";
//                    die;
                    $name = rand().'--'.  base64_encode(json_encode($str)).'.jpeg';
                    //file_put_contents("assets/".$name, base64_decode($server_output));
                    //$url  =  '\assets';
                    //$this->render('otp_verification',array('cheque'=> json_decode($server_output),"url"=>$url.'\\'.$name,"name"=>$name));
                    $this->render('otp_verification',array('cheque_data'=> $name));
                    exit();
                  
                    //$this->redirect(Yii::app()->createUrl('site/otp',array("cheque"=> json_decode($server_output))));
                }

            $this->render('generate_cheque',array('model'=>$model));
        }
        public function actionOtp($cheque){
            
            if(!empty($_POST['otp'])){
                  die("hi");
                    
                    $ch = curl_init();
                    curl_setopt($ch, CURLOPT_URL,"http://del1-lp-23n0cg2/GenerateCheckAPI/api/getCheck/GetCheckImage");
                    curl_setopt($ch, CURLOPT_POST, 1);
                    curl_setopt($ch, CURLOPT_POSTFIELDS,
                                "UserID=".$_POST['token']."&OTPToken=".$_POST['otp']);
                   

                    // in real life you should use something like:
                    // curl_setopt($ch, CURLOPT_POSTFIELDS, 
                    //          http_build_query(array('postvar1' => 'value1')));

                    // receive server response ...
                    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

                    $server_output = curl_exec ($ch);

                    curl_close ($ch);
                    pr($server_output);die;
//                    pr(json_decode($server_output));
//                    echo " <img src='data:image/jpeg;base64, ".json_decode($server_output)."' alt='Red dot' />";
//                    die;
                    $name = rand().'--'.  base64_encode(json_encode($str)).'.jpeg';
                    //file_put_contents("assets/".$name, base64_decode($server_output));
                    //$url  =  '\assets';
                    //$this->render('otp_verification',array('cheque'=> json_decode($server_output),"url"=>$url.'\\'.$name,"name"=>$name));
                    $this->render('otp_verification',array('cheque_data'=> $name));
                    exit();
                  
                    //$this->redirect(Yii::app()->createUrl('site/otp',array("cheque"=> json_decode($server_output))));
                
               $this->redirect(Yii::app()->createUrl('site/get_cheque'));
            }
            $this->render('otp_verification',array('cheque'=> $cheque));
        }
        public function actionDepositCheque(){
             $this->render('deposit_cheque');
        }
        public function actionDepositSuccess(){
             $this->render('deposit_success');
        }

        public function actionForgot(){
            $model = new Users;
            if (!empty($_POST)) {
                $find = Users::model()->findByAttributes(array("email" => $_POST['Users']['username']));
                if (empty($find)) {
                    $this->redirect(array("site/forgot","thankforin"=>1));
                } else {
                    $subject = "MBATrek | Password Recovery";
                    $body = "Hello,<br/><br/>"
                            . "Your Password is - ".$find->password."<br/><br/>"
                            . "<br/><br/ >"
                            . "Thanks,<br/ >"
                            . "MBATrek";
                    $headers="From: ".Yii::app()->params['adminEmail']." <".Yii::app()->params['adminEmail']."> \r\n".
                            "Reply-To: ".Yii::app()->params['adminEmail']." \r\n";

                    $headers .= "MIME-Version: 1.0\r\n".
                                "Content-Type: text/html; charset=UTF-8";
		    
                    $sentToUser = mail($_POST['Users']['username'], $subject,$body,$headers);
                    $this->redirect(array("site/forgot","thankfor"=>1));
                }
            }
            $this->render('forgot',  array('model'=>$model));
        }
        
	public function actionRegisterinstitute()
	{
            $model = new Users;
            if(isset($_POST['Users']))
            {
                    $_POST['Users']['username'] = $_POST['Users']['email'];
                    $_POST['Users']['role'] = 2;
                    $_POST['Users']['is_approve'] = 1;
                    $_POST['Users']['date_registered'] = "'".date('Y-m-d h:i:s')."'";
                    $_POST['Users']['is_verified'] = 0;
                    $model->attributes=$_POST['Users'];
                    try {
                    if($model->save()){
                                $modelInstitute = new Institutes;
                                $modelInstitute->attributes = array("name" => $_POST['Users']['institute_industry_name'],"university_id" => 0);
                                $modelInstitute->save();
                                $modelInUser = new InstituteUser;
                                $modelInUser->attributes = array("institute_id" => $modelInstitute->id,"user_id" => $model->id);
                                $modelInUser->save();
                                $subject = "Your Account Have Been Created";
                                $body = "Hello,<br/><br/>"
                                        . "Your Account has been created .<br/><br/ >"
                                        . "Please click <a href='http://mbatrek.com/index.php?r=site/verify&id=".$model->id."'>here</a>  to verify.<br/><br/ >"
                                        . "Thanks,<br/ >"
                                        . "MBATrek";
                                $headers="From: ".Yii::app()->params['adminEmail']." <".Yii::app()->params['adminEmail']."> \r\n".
                                        "Reply-To: ".Yii::app()->params['adminEmail']." \r\n";

                                $headers .= "MIME-Version: 1.0\r\n".
                                            "Content-Type: text/html; charset=UTF-8";

                                $sentToUser = mail($_POST['Users']['email'], $subject,$body,$headers);
                                
                                $this->success[] = true;
                                $this->refresh(true,"&thankreg=1");
                    }
                    }
                    catch(CDbException $e) {
                            $model->addError('email', 'Email already exist');
                            $this->errors['email'] = 'Email already exist';
                    }
                    
            }
            $this->render('pages/industry_register',  array('model'=>$model));
	}
        
        /**
         * Register Student
         */
	public function actionRegisterstudent()
	{
            $model = new Users;
            if(isset($_POST['Users']))
            {
                    $_POST['Users']['username'] = $_POST['Users']['email'];
                    $_POST['Users']['role'] = 1;
                    $_POST['Users']['is_approve'] = 1;
                    $_POST['Users']['is_verified'] = 0;
                    $_POST['Users']['date_registered'] = date('Y-m-d h:i:s');
                    $_POST['Users']['dob'] = $_POST['example10'];
                    $model->attributes=$_POST['Users'];
                    
                    try {
                    if($model->save()){
                        $modelStudent = new Students;
                        $modelStudent->attributes = array(
                                        "name" =>  $_POST['Users']["fname"]." ".$_POST['Users']["lname"],
                                        "institute_batch_id" =>  $_POST['Users']['batch'],
                                        "user_id" => $model->id,
                                        "profile_json" => json_encode(array()),
                                    );
                        $modelStudent->save();
                        $subject = "Your Account Have Been Created";
                                $body = "Hello,<br/><br/>"
                                        . "Your Account has been created .<br/><br/ >"
                                        . "Please click <a href='http://mbatrek.com/index.php?r=site/verify&id=".$model->id."'>here</a>  to verify.<br/><br/ >"
                                        . "Thanks,<br/ >"
                                        . "MBATrek";
                                $headers="From: ".Yii::app()->params['adminEmail']." <".Yii::app()->params['adminEmail']."> \r\n".
                                        "Reply-To: ".Yii::app()->params['adminEmail']." \r\n";

                                $headers .= "MIME-Version: 1.0\r\n".
                                            "Content-Type: text/html; charset=UTF-8";

                                $sentToUser = mail($_POST['Users']['email'], $subject,$body,$headers);
                                $this->success[] = true;
                                $this->refresh(true,"&thankreg=1");
                    
                    }
                    }
                    catch(CDbException $e) {
                            $model->addError('email', 'Email already exist');
                             $this->errors['email'] = 'Email already exist';
                    }
            }
             
            $this->render('pages/mba_signup_student',  array('model'=>$model));
	}
        /**
         * Register Student
         */
	public function actionRegisterstudentms()
	{
            $model = new Users;
            if(isset($_POST['Users']))
            {
                    $_POST['Users']['username'] = $_POST['Users']['email'];
                    $_POST['Users']['role'] = 1;
                    $_POST['Users']['is_approve'] = 1;
                    $_POST['Users']['is_verified'] = 0;
                    $_POST['Users']['date_registered'] = date('Y-m-d h:i:s');
                    $_POST['Users']['dob'] = $_POST['example10']; 
                    $model->attributes=$_POST['Users'];
                    try {
                    if($model->save()){
                        $modelStudent = new Students;
                        $modelStudent->attributes = array(
                                        "name" =>  $_POST['Users']["fname"]." ".$_POST['Users']["lname"],
                                        "institute_batch_id" =>  $_POST['Users']['batch'],
                                        "user_id" => $model->id,
                                        "profile_json" => json_encode(array()),
                                    );
                        $modelStudent->save();
                        $subject = "Your Account Have Been Created";
                                $body = "Hello,<br/><br/>"
                                        . "Your Account has been created .<br/><br/ >"
                                        . "Please click <a href='http://mbatrek.com/index.php?r=site/verify&id=".$model->id."'>here</a>  to verify.<br/><br/ >"
                                        . "Thanks,<br/ >"
                                        . "MBATrek";
                                $headers="From: ".Yii::app()->params['adminEmail']." <".Yii::app()->params['adminEmail']."> \r\n".
                                        "Reply-To: ".Yii::app()->params['adminEmail']." \r\n";

                                $headers .= "MIME-Version: 1.0\r\n".
                                            "Content-Type: text/html; charset=UTF-8";

                                $sentToUser = mail($_POST['Users']['email'], $subject,$body,$headers);
                        $this->success[] = true;
                       $this->refresh(true,"&thankreg=1");
                    
                    }
                    }
                    catch(CDbException $e) {
                            $model->addError('email', 'Email already exist');
                             $this->errors['email'] = 'Email already exist';
                    }
            }
            $this->render('pages/ms_signup_student',  array('model'=>$model));
	}
        /**
         * Register Student
         */
	public function actionRegisterstudentgrand()
	{
            $model = new Users;
            if(isset($_POST['Users']))
            {
                    $_POST['Users']['username'] = $_POST['Users']['email'];
                    $_POST['Users']['role'] = 1;
                    $_POST['Users']['is_approve'] = 1;
                    $_POST['Users']['is_verified'] = 0;
                    $_POST['Users']['dob'] = $_POST['example10'];
                    $_POST['Users']['date_registered'] = date('Y-m-d h:i:s');
                    $model->attributes=$_POST['Users'];
                    try {
                    if($model->save()){
                        $subject = "Your Account Have Been Created";
                                $body = "Hello,<br/><br/>"
                                        . "Your Account has been created .<br/><br/ >"
                                        . "Please click <a href='http://mbatrek.com/index.php?r=site/verify&id=".$model->id."'>here</a>  to verify.<br/><br/ >"
                                        . "Thanks,<br/ >"
                                        . "MBATrek";
                                $headers="From: ".Yii::app()->params['adminEmail']." <".Yii::app()->params['adminEmail']."> \r\n".
                                        "Reply-To: ".Yii::app()->params['adminEmail']." \r\n";

                                $headers .= "MIME-Version: 1.0\r\n".
                                            "Content-Type: text/html; charset=UTF-8";

                                $sentToUser = mail($_POST['Users']['email'], $subject,$body,$headers);
                        $this->success[] = true;
                        $this->refresh(true,"&thankreg=1");
                    
                    }
                    }
                    catch(CDbException $e) {
                            $model->addError('email', 'Email already exist');
                             $this->errors['email'] = 'Email already exist';
                    }
            }
            $this->render('pages/grandexplore_signup_student',  array('model'=>$model));
	}
	/**
	 * This is the default 'index' action that is invoked
	 * when an action is not explicitly requested by users.
	 */
	public function actionDownload($id = null, $category_id = null) 
	{
            $this->pageTitle = "Home";
		// renders the view file 'protected/views/site/index.php'
		// using the default layout 'protected/views/layouts/main.php'
            $model = new EbroucherDownloadForm();
            if(isset($_POST['EbroucherDownloadForm']))
            {
                    $model->attributes=$_POST['EbroucherDownloadForm'];
                    if($model->save() && $category_id!= null){
                        $url = Yii::app()->createAbsoluteUrl("site/downloadall", array("category_id"=>$category_id));
                        $data = array("url" => $url);
                        echo json_encode($data);
                        exit;
//                        echo '<script>window.open("'.$url.'");</script>';
                    }else if($model->save() && $id!= null){
                        $url = Yii::app()->createAbsoluteUrl("site/downladone", array("id"=>$id));
                        $data = array("url" => $url);
                        echo json_encode($data);
                        exit;
//                        echo '<script>window.open("'.$url.'");</script>';
//                        $this->redirect(Yii::app()->createUrl('site/index'));
                    } else {
                        $data = array("url" => $url);
                        echo json_encode($data);
                        exit;
                    }
                        
            } 
            $this->render('download',array('model'=>$model));
	}
	/**
	 * This is the default 'index' action that is invoked
	 * when an action is not explicitly requested by users.
	 */
	public function actionDownladone($id)
	{
            
            $model = Ebrouchers::model()->findByAttributes(array('id'=>$id));

            $basename = basename($model->file);
            $filename =  getcwd().'/assets/eBrouchers/' . $basename; // don't accept other directories
            
            $mime = ($mime = getimagesize($filename)) ? $mime['mime'] : $mime;
            $size = filesize($filename);
            $fp   = fopen($filename, "rb");
            if (!($mime && $size && $fp)) {
              // Error.
//              return;
            }

            header("Content-type: " . $mime);
            header("Content-Length: " . $size);
            // NOTE: Possible header injection via $basename
            header("Content-Disposition: attachment; filename=" . $basename);
            header('Content-Transfer-Encoding: binary');
            header('Cache-Control: must-revalidate, post-check=0, pre-check=0');
            fpassthru($fp);
            flush();
            
	}
        /* creates a compressed zip file */
        public function create_zip($files = array(), $destination = '', $overwrite = false) {
                //if the zip file already exists and overwrite is false, return false
                if (file_exists($destination) && !$overwrite) {
                    return false;
                }
                //vars
                $valid_files = array();
                //if files were passed in...
                if (is_array($files)) {
                    //cycle through each file
                    foreach ($files as $file) {
                        //make sure the file exists
                        if (file_exists($file)) {
                            $valid_files[] = $file;
                        }
                    }
                }
                //if we have good files...
                if (count($valid_files)) {
                    //create the archive
                    $zip = new ZipArchive();
                    if ($zip->open($destination, $overwrite ? ZIPARCHIVE::OVERWRITE : ZIPARCHIVE::CREATE) !== true) {
                        return false;
                    }
                    //add the files
                    foreach ($valid_files as $file) {
                        $zip->addFile($file, $file);
                    }
                    //debug
                    //echo 'The zip archive contains ',$zip->numFiles,' files with a status of ',$zip->status;
                    //close the zip -- done!
                    $zip->close();

                    //check to make sure the file exists
                    return file_exists($destination);
                } else {
                    return false;
                }
            }

            /**
	 * This is the default 'index' action that is invoked
	 * when an action is not explicitly requested by users.
	 */
	public function actionDowloadall($category_id)
	{
            $model = Ebrouchers::model()->findAllByAttributes(array('category_id'=>$category_id));
            foreach ($model as $files){
                $filesall[] = getcwd().'/assets/eBrouchers/' .$files->file;
            }
            $destination = 'downlaod.zip';
            $this->create_zip($filesall, $destination);
            $file_name = basename($destination);

            header("Content-Type: application/zip");
            header("Content-Disposition: attachment; filename=$file_name");
            header("Content-Length: " . filesize($destination));

            readfile($yourfile);
            exit;
	}

	/**
	 * This is the action to handle external exceptions.
	 */
	public function actionError()
	{
		if($error=Yii::app()->errorHandler->error)
		{
			if(Yii::app()->request->isAjaxRequest)
				echo $error['message'];
			else
				$this->render('error', $error);
		}
	}

	/**
	 * Displays the contact page
	 */
	public function actionContact()
	{
		$model=new ContactForm;
		if(isset($_POST['ContactForm']))
		{
			$model->attributes=$_POST['ContactForm'];
			if($model->validate())
			{
				$name='=?UTF-8?B?'.base64_encode($model->name).'?=';
				$subject='=?UTF-8?B?'.base64_encode($model->subject).'?=';
				$headers="From: $name <{$model->email}>\r\n".
					"Reply-To: {$model->email}\r\n".
					"MIME-Version: 1.0\r\n".
					"Content-Type: text/plain; charset=UTF-8";

				mail(Yii::app()->params['adminEmail'],$subject,$model->body,$headers);
				Yii::app()->user->setFlash('contact','Thank you for contacting us. We will respond to you as soon as possible.');
				$this->refresh();
			}
		}
		$this->render('contact',array('model'=>$model));
	}

	/**
	 * Displays the login page
	 */
	public function actionLogin()
	{
		$model=new LoginForm;

		// if it is ajax validation request
		if(isset($_POST['ajax']) && $_POST['ajax']==='login-form')
		{
			echo CActiveForm::validate($model);
			Yii::app()->end();
		}

		// collect user input data
                
		if(isset($_POST['LoginForm']))
		{
                        
			$model->attributes=$_POST['LoginForm'];
			// validate user input and redirect to the previous page if valid
			if($model->validate() && $model->login()){
                            $model2 = Users::model()->findByPk(Yii::app()->user->id);
			    $model2->attributes=array("login_count"=>($model2->login_count+1));
			    $model2->save(); 
                            if (Yii::app()->user->admin == 0) {
                                $this->redirect(Yii::app()->createUrl('/users/admin',array("role"=>1)));
                            } else if(Yii::app()->user->admin == 1){
				$studProfile = Students::model()->findByAttributes(array("user_id"=>  Yii::app()->user->id));
				if (isset($studProfile->instituteBatch->institute_id) && $studProfile->instituteBatch->institute_id == 0) {
				   if ($model2->login_count > 6){
				       $this->redirect(Yii::app()->createUrl('student/portal'));
				   } else{
				       $this->redirect(Yii::app()->createUrl('site/page&view=student'));
				   }
				} else{
				    $this->redirect(Yii::app()->createUrl('student/portal'));
				}
                                
                            } else if(Yii::app()->user->admin == 2){
                                $this->redirect(Yii::app()->createUrl('institutes/portal'));
                            } else {
                                $this->redirect(Yii::app()->createUrl('industry/portal'));
                            }
                        } else {
                            foreach($model->getErrors() as $key=>$errors){
                                $this->errors[$key]  = $errors[0];
                            }
                        }
		}
		// display the login form
		$this->render('login',array('model'=>$model));
	}

	/**
	 * Logs out the current user and redirect to homepage.
	 */
	public function actionLogout()
	{
            Yii::app()->user->logout();
            $this->redirect(Yii::app()->homeUrl);
	}
        
        /**
	 * Logs out the current user and redirect to homepage.
	 */
	public function actionBlogs()
	{  
            $criteria=new CDbCriteria();
            $criteria->order = "date_updated desc";
            if(isset($_GET['cat_id'])) {
                 $criteria->addCondition("blog_category_id = ".$_GET['cat_id']);
            }
            $count=  Blogs::model()->count($criteria);
            $pages=new CPagination($count);

            // results per page
            $pages->pageSize=9;
            $pages->applyLimit($criteria);
            $models=Blogs::model()->findAll($criteria);
            
            // display the login form
            $this->render('blogs', array(
                'models' => $models,
                     'pages' => $pages
                ));
	}
        /**
	 * Logs out the current user and redirect to homepage.
	 */
	public function actionArticles()
	{  
            $criteria=new CDbCriteria();
            
            if(isset($_GET['type'])) {
                 $criteria->addCondition("type = ".$_GET['type']);
            }
            $count= Articles::model()->count($criteria);
            $pages=new CPagination($count);

            // results per page
            $pages->pageSize=9;
            $pages->applyLimit($criteria);
            $models=Articles::model()->findAll($criteria);
            
            // display the login form
            $this->render('articles', array(
                'models' => $models,
                     'pages' => $pages
                ));
	}
        /**
	 * Logs out the current user and redirect to homepage.
	 */
	public function actionArticledetails($id)
	{  
            
            
            $criteria=new CDbCriteria();
            
            $criteria->addCondition("id = ".$id);
            
            $model=Articles::model()->find($criteria);
            
            
            $criteria=new CDbCriteria();
            
            $count=  Articles::model()->count($criteria);
            $pages=new CPagination($count);

            // results per page
            $pages->pageSize=4;
            $pages->applyLimit($criteria);
            $latest=Articles::model()->findAll($criteria);
            // display the login form
            $this->render('articledetails', array(
                'model' => $model,
            ));
	}
        /**
	 * Logs out the current user and redirect to homepage.
	 */
	public function actionVideos()
	{  
            $criteria=new CDbCriteria();
            
            $count= Videos::model()->count($criteria);
            $pages=new CPagination($count);

            // results per page
            $pages->pageSize=9;
            $pages->applyLimit($criteria);
            $models=Videos::model()->findAll($criteria);
            
            // display the login form
            $this->render('pages/videos', array(
                'models' => $models,
                     'pages' => $pages
                ));
	}
        /**
	 * Logs out the current user and redirect to homepage.
	 */
	public function actionBlogdetails($id)
	{  
            
            if (!empty($_POST)) {
                
                $comment = new BlogComments;
                $comment->attributes = array(
                    "blog_id" =>$id,
                    "name" =>$_POST['name'],
                    "email" =>$_POST['email'],
                    "comment" =>$_POST['comment'],
                    "is_approved" =>0,
                    "date_created" => date("Y-m-d h:i:s"),
                );
                if ($comment->save()) {
                    $subject = "Your Comment Have Been Added";
                    $body = "Hello,<br/><br/>"
                            . "Your comment has been added and is under review.<br/><br/ >"
                            . "Your comment will appear once approved.<br/><br/ >"
                            . "Thanks,<br/ >"
                            . "MBATrek";
                    $headers="From: ".Yii::app()->params['adminEmail']." <".Yii::app()->params['adminEmail']."> \r\n".
                            "Reply-To: ".Yii::app()->params['adminEmail']." \r\n";

                    $headers .= "MIME-Version: 1.0\r\n".
                                "Content-Type: text/html; charset=UTF-8";

                    $sentToUser = mail($_POST['email'], $subject,$body,$headers);
                    $this->refresh();
                } 
            }
            $criteria=new CDbCriteria();
            $criteria->order = "date_updated desc";
            $criteria->addCondition("id = ".$id);
            $model=Blogs::model()->find($criteria);
            $approvedComments = BlogComments::model()->findAllByAttributes(array("blog_id"=>$id,"is_approved" =>1));
            
            $criteria=new CDbCriteria();
            $criteria->order = "date_updated desc";
            $count=  Blogs::model()->count($criteria);
            $pages=new CPagination($count);

            // results per page
            $pages->pageSize=4;
            $pages->applyLimit($criteria);
            $latest=Blogs::model()->findAll($criteria);
            // display the login form
            $this->render('blogdetails', array(
                'model' => $model,
                'comments' => $approvedComments,
                'latests' => $latest,
            ));
	}
        
        public function actionGetprograms(){
            $data = InstituteCourse::model()->findAllByAttributes(array("institute_id"=>$_POST['institute_id']));
            $html = "<option value=''>Select Program</option>";
            foreach ($data as $d){
                $html .= '<option value="'.$d->course_id.'">'.$d->course->name."</option>";
            }
            echo $html;
            exit;
        }
        public function actionVerify($id){
            $model = Users::model()->findByPk($id);
            $model->attributes = array("is_verified" => 1);
            if ($model->save()) {
                $this->redirect(array('site/index','tv'=>1));
            }else {
                $this->redirect(array('site/index','tv'=>0));
            }
        }
        public function actionBatch(){
            $data = InstituteBatches::model()->findAllByAttributes(array("institute_course_id"=>$_POST['institute_course_id']));
            $html = "<option value=''>Select Batch</option>";
            foreach ($data as $d){
                $html .= '<option value="'.$d->id.'">'.$d->name."</option>";
            }
            echo $html;
            exit;
        }
        
        public function actionDownloadfiles($path,$name){
            downloadFile(getcwd().$path,$name);
        }
        
        
}?>