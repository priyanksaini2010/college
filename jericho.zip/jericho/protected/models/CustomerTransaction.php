<?php

/**
 * This is the model class for table "customer_transaction".
 *
 * The followings are the available columns in table 'customer_transaction':
 * @property integer $id
 * @property integer $customer_id_payer
 * @property integer $customer_id_payee
 * @property string $transaction_id
 * @property double $amount
 * @property string $transaction_description
 * @property string $transaction_date
 * @property integer $is_completed
 *
 * The followings are the available model relations:
 * @property Customers $customerIdPayer
 * @property Customers $customerIdPayee
 */
class CustomerTransaction extends CActiveRecord
{
	/**
	 * @return string the associated database table name
	 */
	public function tableName()
	{
		return 'customer_transaction';
	}

	/**
	 * @return array validation rules for model attributes.
	 */
	public function rules()
	{
		// NOTE: you should only define rules for those attributes that
		// will receive user inputs.
		return array(
			array('customer_id_payer, customer_id_payee, transaction_id, amount, transaction_description, transaction_date, is_completed', 'required'),
			array('customer_id_payer, customer_id_payee, is_completed', 'numerical', 'integerOnly'=>true),
			array('amount', 'numerical'),
			array('transaction_id', 'length', 'max'=>150),
			// The following rule is used by search().
			// @todo Please remove those attributes that should not be searched.
			array('id, customer_id_payer, customer_id_payee, transaction_id, amount, transaction_description, transaction_date, is_completed', 'safe', 'on'=>'search'),
		);
	}

	/**
	 * @return array relational rules.
	 */
	public function relations()
	{
		// NOTE: you may need to adjust the relation name and the related
		// class name for the relations automatically generated below.
		return array(
			'customerIdPayer' => array(self::BELONGS_TO, 'Customers', 'customer_id_payer'),
			'customerIdPayee' => array(self::BELONGS_TO, 'Customers', 'customer_id_payee'),
		);
	}

	/**
	 * @return array customized attribute labels (name=>label)
	 */
	public function attributeLabels()
	{
		return array(
			'id' => 'ID',
			'customer_id_payer' => 'Customer Id Payer',
			'customer_id_payee' => 'Customer Id Payee',
			'transaction_id' => 'Transaction',
			'amount' => 'Amount',
			'transaction_description' => 'Transaction Description',
			'transaction_date' => 'Transaction Date',
			'is_completed' => 'Is Completed',
		);
	}

	/**
	 * Retrieves a list of models based on the current search/filter conditions.
	 *
	 * Typical usecase:
	 * - Initialize the model fields with values from filter form.
	 * - Execute this method to get CActiveDataProvider instance which will filter
	 * models according to data in model fields.
	 * - Pass data provider to CGridView, CListView or any similar widget.
	 *
	 * @return CActiveDataProvider the data provider that can return the models
	 * based on the search/filter conditions.
	 */
	public function search()
	{
		// @todo Please modify the following code to remove attributes that should not be searched.

		$criteria=new CDbCriteria;

		$criteria->compare('id',$this->id);
		$criteria->compare('customer_id_payer',$this->customer_id_payer);
		$criteria->compare('customer_id_payee',$this->customer_id_payee);
		$criteria->compare('transaction_id',$this->transaction_id,true);
		$criteria->compare('amount',$this->amount);
		$criteria->compare('transaction_description',$this->transaction_description,true);
		$criteria->compare('transaction_date',$this->transaction_date,true);
		$criteria->compare('is_completed',$this->is_completed);

		return new CActiveDataProvider($this, array(
			'criteria'=>$criteria,
		));
	}

	/**
	 * Returns the static model of the specified AR class.
	 * Please note that you should have this exact method in all your CActiveRecord descendants!
	 * @param string $className active record class name.
	 * @return CustomerTransaction the static model class
	 */
	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}
}
