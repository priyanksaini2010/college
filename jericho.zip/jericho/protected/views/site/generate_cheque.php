    <?php $this->setPageTitle("Generate Cheque"); ?>
<div class="main-content-inner">
    <div class="breadcrumbs ace-save-state" id="breadcrumbs">
        <ul class="breadcrumb">
            <li>
                <i class="ace-icon fa fa-home home-icon"></i>
                <a href="<?php echo Yii::app()->createUrl("site/dashboard")?>">Home</a>
            </li>
            <li class="active">Generate Cheque</li>
        </ul><!-- /.breadcrumb -->

        <div class="nav-search" id="nav-search">
            <form class="form-search">
                <span class="input-icon">
                    <input type="text" placeholder="Search ..." class="nav-search-input" id="nav-search-input" autocomplete="off" />
                    <i class="ace-icon fa fa-search nav-search-icon"></i>
                </span>
            </form>
        </div><!-- /.nav-search -->
    </div>

    <div class="page-content">


        <div class="page-header">
            <h1>
                Generate Cheque
                
            </h1>
        </div><!-- /.page-header -->

        <div class="row">
            <div class="col-xs-12">
                <!-- PAGE CONTENT BEGINS -->
              

               
               
                   <?php
                                    $form = $this->beginWidget('CActiveForm', array(
                                        'id' => 'cheque-form',
                                        //'class' => 'form-horizontal',
                                        'enableClientValidation' => true,
                                        'enableAjaxValidation' => true,
                                        'clientOptions' => array(
                                            'validateOnSubmit' => true,
                                            'validateOnChange' => true
                                        ),
                                        'htmlOptions'=>array(
                                            'class'=>'form-horizontal',
                                            )
                                    ));
                                    $accountName = $form->error($model, 'accountName');
                                    $accountNumber = $form->error($model, 'accountNumber');
                                    $amount = $form->error($model, 'amount');
                                    ?>
                            <?php echo $form->hiddenField($model, 'token', array('value'=>Yii::app()->user->token)); ?>
									<div class="form-group">
										<label class="col-sm-3 control-label no-padding-right" for="form-field-1"> Payee Name  </label>

										<div class="col-sm-9">
											
                                                                                        <?php echo $form->textField($model, 'accountName', array('class'=>"col-xs-10 col-sm-5", 'placeholder'=>"Payee Name")); ?>
										</div>
									</div>
                   <div class="form-group">
										<label class="col-sm-3 control-label no-padding-right" for="form-field-1"> Account Number </label>

										<div class="col-sm-9">
											<?php echo $form->textField($model, 'accountNumber', array('class'=>"col-xs-10 col-sm-5", 'placeholder'=>"Account Number")); ?>
										</div>
									</div>
                   <div class="form-group">
										<label class="col-sm-3 control-label no-padding-right" for="form-field-1"> Amount </label>

										<div class="col-sm-9">
											<?php echo $form->textField($model, 'amount', array('class'=>"col-xs-10 col-sm-5", 'placeholder'=>"Amount")); ?>
										</div>
									</div>
                   <div class="form-group">
										<label class="col-sm-3 control-label no-padding-right" for="form-field-1"> Date </label>

										<div class="col-sm-9">
											
                                                                                    <?php echo $form->textField($model, 'date', array('class'=>"col-xs-10 col-sm-5 input-mask-date", 'placeholder'=>"dd/mm/yyyy")); ?>
																
										</div>
									</div>
                   <div class="clearfix"></div>
<!--                    <div id="signature-pad" class="m-signature-pad">
    <div class="m-signature-pad--body">
      <canvas></canvas>
    </div>
    <div class="m-signature-pad--footer">
      <div class="description">Sign above</div>
      <div class="left">
        <button type="button" class="button clear" data-action="clear">Clear</button>
      </div>
      <div class="right">
        <button type="button" class="button save" data-action="save-png">Save as PNG</button>
        <button type="button" class="button save" data-action="save-svg">Save as SVG</button>
      </div>
    </div>
  </div>-->
                   <div class="clearfix form-actions">
										<div class="col-md-offset-3 col-md-9">
											<button class="btn btn-info" type="submit">
												<i class="ace-icon fa fa-check bigger-110"></i>
												Submit
											</button>

											&nbsp; &nbsp; &nbsp;
											<button class="btn" type="reset">
												<i class="ace-icon fa fa-undo bigger-110"></i>
												Reset
											</button>
										</div>
									</div>
               <?php $this->endWidget();?>








                <!-- PAGE CONTENT ENDS -->
            </div><!-- /.col -->
        </div><!-- /.row -->
    </div><!-- /.page-content -->
</div>
<script src="assets/js/jquery-ui.custom.min.js"></script>
		<script src="assets/js/jquery.ui.touch-punch.min.js"></script>
		<script src="assets/js/chosen.jquery.min.js"></script>
		<script src="assets/js/spinbox.min.js"></script>
		<script src="assets/js/bootstrap-datepicker.min.js"></script>
		<script src="assets/js/bootstrap-timepicker.min.js"></script>
		<script src="assets/js/moment.min.js"></script>
		<script src="assets/js/daterangepicker.min.js"></script>
		<script src="assets/js/bootstrap-datetimepicker.min.js"></script>
		<script src="assets/js/bootstrap-colorpicker.min.js"></script>
		<script src="assets/js/jquery.knob.min.js"></script>
		<script src="assets/js/autosize.min.js"></script>
		<script src="assets/js/jquery.inputlimiter.min.js"></script>
		<script src="assets/js/jquery.maskedinput.min.js"></script>
		<script src="assets/js/bootstrap-tag.min.js"></script>
<script>
    jQuery(function($) {
    $.mask.definitions['~']='[+-]';
    $('.input-mask-date').mask('99/99/9999');
    });
</script>
    