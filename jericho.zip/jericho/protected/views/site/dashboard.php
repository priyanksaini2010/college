<?php $this->setPageTitle("Dashboard"); ?>
<div class="main-content-inner">
    <div class="breadcrumbs ace-save-state" id="breadcrumbs">
        <ul class="breadcrumb">
            <li>
                <i class="ace-icon fa fa-home home-icon"></i>
                <a href="#">Home</a>
            </li>
            <li class="active">Dashboard</li>
        </ul><!-- /.breadcrumb -->

        <div class="nav-search" id="nav-search">
            <form class="form-search">
                <span class="input-icon">
                    <input type="text" placeholder="Search ..." class="nav-search-input" id="nav-search-input" autocomplete="off" />
                    <i class="ace-icon fa fa-search nav-search-icon"></i>
                </span>
            </form>
        </div><!-- /.nav-search -->
    </div>

    <div class="page-content">


        <div class="page-header">
            <h1>
                Dashboard
                <small>
                    <i class="ace-icon fa fa-angle-double-right"></i>
                    overview &amp; stats
                </small>
            </h1>
        </div><!-- /.page-header -->

        <div class="row">
            <div class="col-xs-12">
                <!-- PAGE CONTENT BEGINS -->
                <div class="alert alert-block alert-success">
                    <button type="button" class="close" data-dismiss="alert">
                        <i class="ace-icon fa fa-times"></i>
                    </button>

                    <i class="ace-icon fa fa-check green"></i>

                    Welcome <?php echo Yii::app()->user->name; ?>
               </div>

                <div class="col-xs-12">
                    <!-- PAGE CONTENT BEGINS -->
                    <div class="invisible" id="main-widget-container">
                        <div class="row">
                            <div class="col-xs-12 col-sm-6 widget-container-col" id="widget-container-col-1">
                                <div class="widget-box" id="widget-box-1">
                                    <div class="widget-header">
                                        <h5 class="widget-title">I have</h5>

                                        <div class="widget-toolbar">
                                            <div class="widget-menu">
                                                <a href="#" data-action="settings" data-toggle="dropdown">
                                                    <i class="ace-icon fa fa-bars"></i>
                                                </a>

                                                <ul class="dropdown-menu dropdown-menu-right dropdown-light-blue dropdown-caret dropdown-closer">
                                                    <li>
                                                        <a data-toggle="tab" href="#dropdown1">Option#1</a>
                                                    </li>

                                                    <li>
                                                        <a data-toggle="tab" href="#dropdown2">Option#2</a>
                                                    </li>
                                                </ul>
                                            </div>

                                            <a href="#" data-action="fullscreen" class="orange2">
                                                <i class="ace-icon fa fa-expand"></i>
                                            </a>

                                            <a href="#" data-action="reload">
                                                <i class="ace-icon fa fa-refresh"></i>
                                            </a>

                                            <a href="#" data-action="collapse">
                                                <i class="ace-icon fa fa-chevron-up"></i>
                                            </a>

                                            <a href="#" data-action="close">
                                                <i class="ace-icon fa fa-times"></i>
                                            </a>
                                        </div>
                                    </div>

                                    <div class="widget-body">
                                        <div class="widget-main">
                                           <div class="profile-user-info profile-user-info-striped">
                                               <?php foreach ($debit_data as $key => $debit) { ?>
												<div class="profile-info-row">
													<div class="profile-info-name"> <?php echo $key;?> </div>

													<div class="profile-info-value">
														<span class="editable editable-click" id="username">INR <?php echo $debit;?></span>
													</div>
												</div>
                                               <?php } ?>
				

											

											</div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xs-12 col-sm-6 widget-container-col" id="widget-container-col-1">
                                <div class="widget-box" id="widget-box-1">
                                    <div class="widget-header">
                                        <h5 class="widget-title">I owe</h5>

                                        <div class="widget-toolbar">
                                            <div class="widget-menu">
                                                <a href="#" data-action="settings" data-toggle="dropdown">
                                                    <i class="ace-icon fa fa-bars"></i>
                                                </a>

                                                <ul class="dropdown-menu dropdown-menu-right dropdown-light-blue dropdown-caret dropdown-closer">
                                                    <li>
                                                        <a data-toggle="tab" href="#dropdown1">Option#1</a>
                                                    </li>

                                                    <li>
                                                        <a data-toggle="tab" href="#dropdown2">Option#2</a>
                                                    </li>
                                                </ul>
                                            </div>

                                            <a href="#" data-action="fullscreen" class="orange2">
                                                <i class="ace-icon fa fa-expand"></i>
                                            </a>

                                            <a href="#" data-action="reload">
                                                <i class="ace-icon fa fa-refresh"></i>
                                            </a>

                                            <a href="#" data-action="collapse">
                                                <i class="ace-icon fa fa-chevron-up"></i>
                                            </a>

                                            <a href="#" data-action="close">
                                                <i class="ace-icon fa fa-times"></i>
                                            </a>
                                        </div>
                                    </div>

                                         <div class="widget-body">
                                        <div class="widget-main">
                                           <div class="profile-user-info profile-user-info-striped">
                                               <?php foreach ($credit_data as $key => $debit) { ?>
												<div class="profile-info-row">
													<div class="profile-info-name"> <?php echo $key;?> </div>

													<div class="profile-info-value">
														<span class="editable editable-click" id="username">INR <?php echo $debit;?></span>
													</div>
												</div>
                                               <?php } ?>
				

											

											</div>
                                        </div>
                                    </div>
                                </div>
                            </div>


                        </div><!-- /.row -->

                        <div class="space-24"></div>
                        <div class="row">
<div class="col-sm-12  widget-container-col ui-sortable" id="widget-container-col-11">
											<div class="widget-box widget-color-dark ui-sortable-handle" id="widget-box-11">
												<div class="widget-header">
													<h6 class="widget-title">Messages and Alerts</h6>

													<div class="widget-toolbar">
														<a href="#" data-action="settings">
															<i class="ace-icon fa fa-cog"></i>
														</a>

														<a href="#" data-action="reload">
															<i class="ace-icon fa fa-refresh"></i>
														</a>

														<a href="#" data-action="collapse">
															<i class="ace-icon fa fa-chevron-up"></i>
														</a>

														<a href="#" data-action="close">
															<i class="ace-icon fa fa-times"></i>
														</a>

														<a href="#" data-action="fullscreen" class="orange2">
															<i class="ace-icon fa fa-expand"></i>
														</a>
													</div>
												</div>

												<div class="widget-body">
													<div class="widget-main padding-4 scrollable ace-scroll" data-size="125" style="position: relative;"><div class="scroll-track scroll-active" style="display: block; height: 125px;"><div class="scroll-bar" style="height: 8px; top: 0px;"></div></div><div class="scroll-content" style="max-height: 125px;">
														<div class="content">
															<div class="alert alert-info">
																Lorem ipsum dolor sit amet, consectetur adipiscing.
															</div>
															<div class="alert alert-danger">
																Lorem ipsum dolor sit amet, consectetur adipiscing.
															</div>
															<div class="alert alert-success">
																Lorem ipsum dolor sit amet, consectetur adipiscing.
															</div>
															<div class="alert">
																Lorem ipsum dolor sit amet, consectetur adipiscing.
															</div>
															<div class="alert alert-info">
																Lorem ipsum dolor sit amet, consectetur adipiscing.
															</div>
															<div class="alert alert-danger">
																Lorem ipsum dolor sit amet, consectetur adipiscing.
															</div>
															<div class="alert alert-success">
																Lorem ipsum dolor sit amet, consectetur adipiscing.
															</div>
															<div class="alert">
																Lorem ipsum dolor sit amet, consectetur adipiscing.
															</div>
															<div class="alert alert-info">
																Lorem ipsum dolor sit amet, consectetur adipiscing.
															</div>
															<div class="alert alert-danger">
																Lorem ipsum dolor sit amet, consectetur adipiscing.
															</div>
															<div class="alert alert-success">
																Lorem ipsum dolor sit amet, consectetur adipiscing.
															</div>
															<div class="alert">
																Lorem ipsum dolor sit amet, consectetur adipiscing.
															</div>
															<div class="alert alert-info">
																Lorem ipsum dolor sit amet, consectetur adipiscing.
															</div>
															<div class="alert alert-danger">
																Lorem ipsum dolor sit amet, consectetur adipiscing.
															</div>
															<div class="alert alert-success">
																Lorem ipsum dolor sit amet, consectetur adipiscing.
															</div>
															<div class="alert">
																Lorem ipsum dolor sit amet, consectetur adipiscing.
															</div>
															<div class="alert alert-info">
																Lorem ipsum dolor sit amet, consectetur adipiscing.
															</div>
															<div class="alert alert-danger">
																Lorem ipsum dolor sit amet, consectetur adipiscing.
															</div>
															<div class="alert alert-success">
																Lorem ipsum dolor sit amet, consectetur adipiscing.
															</div>
															<div class="alert">
																Lorem ipsum dolor sit amet, consectetur adipiscing.
															</div>
															<div class="alert alert-info">
																Lorem ipsum dolor sit amet, consectetur adipiscing.
															</div>
															<div class="alert alert-danger">
																Lorem ipsum dolor sit amet, consectetur adipiscing.
															</div>
															<div class="alert alert-success">
																Lorem ipsum dolor sit amet, consectetur adipiscing.
															</div>
															<div class="alert">
																Lorem ipsum dolor sit amet, consectetur adipiscing.
															</div>
															<div class="alert alert-info">
																Lorem ipsum dolor sit amet, consectetur adipiscing.
															</div>
															<div class="alert alert-success">
																Lorem ipsum dolor sit amet, consectetur adipiscing.
															</div>
															<div class="alert">
																Lorem ipsum dolor sit amet, consectetur adipiscing.
															</div>
															<div class="alert alert-info">
																Lorem ipsum dolor sit amet, consectetur adipiscing.
															</div>
														</div>
													</div></div>
												</div>
											</div>
										</div>
                        </div>






                    </div><!-- PAGE CONTENT ENDS -->
                </div><!-- /.col -->








                <!-- PAGE CONTENT ENDS -->
            </div><!-- /.col -->
        </div><!-- /.row -->
    </div><!-- /.page-content -->
</div>

