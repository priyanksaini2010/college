<?php $this->setPageTitle("Dashboard"); ?>
<div class="main-content-inner">
    <div class="breadcrumbs ace-save-state" id="breadcrumbs">
        <ul class="breadcrumb">
            <li>
                <i class="ace-icon fa fa-home home-icon"></i>
                <a href="#">Home</a>
            </li>
            <li class="active">Generate Cheque</li>
        </ul><!-- /.breadcrumb -->

        <div class="nav-search" id="nav-search">
            <form class="form-search">
                <span class="input-icon">
                    <input type="text" placeholder="Search ..." class="nav-search-input" id="nav-search-input" autocomplete="off" />
                    <i class="ace-icon fa fa-search nav-search-icon"></i>
                </span>
            </form>
        </div><!-- /.nav-search -->
    </div>

    <div class="page-content">


        <div class="page-header">
            <h1>
                Generate Cheque

            </h1>
        </div><!-- /.page-header -->

        <div class="row">
            <div class="col-xs-12">
                <!-- PAGE CONTENT BEGINS -->




               
                <img src='data:image/jpeg;base64,<?php echo $cheque ?>'alt='Red dot' />
                
              
                <div class="clearfix"></div>
                <div class="clearfix form-actions">
                    <div class="col-md-offset-3 col-md-9">
                        <a class="btn btn-info" href="<?php echo Yii::app()->createUrl('site/downloadfiles', array('path' => $url,'name'=>$name)) ?>">
                            <i class="ace-icon fa fa-check bigger-110"></i>
                            Download
                        </a>

                      
                    </div>
                   
                </div>
              








                <!-- PAGE CONTENT ENDS -->
            </div><!-- /.col -->
            
        </div><!-- /.row -->
    </div><!-- /.page-content -->
</div>