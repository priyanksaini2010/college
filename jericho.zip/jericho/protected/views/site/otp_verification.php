<?php $this->setPageTitle("Dashboard"); ?>
<div class="main-content-inner">
    <div class="breadcrumbs ace-save-state" id="breadcrumbs">
        <ul class="breadcrumb">
            <li>
                <i class="ace-icon fa fa-home home-icon"></i>
                <a href="#">Home</a>
            </li>
            <li class="active">Generate Cheque</li>
        </ul><!-- /.breadcrumb -->

        <div class="nav-search" id="nav-search">
            <form class="form-search">
                <span class="input-icon">
                    <input type="text" placeholder="Search ..." class="nav-search-input" id="nav-search-input" autocomplete="off" />
                    <i class="ace-icon fa fa-search nav-search-icon"></i>
                </span>
            </form>
        </div><!-- /.nav-search -->
    </div>

    <div class="page-content">


        <div class="page-header">
            <h1>
                Generate Cheque

            </h1>
        </div><!-- /.page-header -->

        <div class="row">
            <div class="col-xs-12">
                <!-- PAGE CONTENT BEGINS -->




                <?php
                                    $form = $this->beginWidget('CActiveForm', array(
                                        'id' => 'login-form',
                                        'enableClientValidation' => true,
                                        'enableAjaxValidation' => true,
                                        'clientOptions' => array(
                                            'validateOnSubmit' => true,
                                            'validateOnChange' => true
                                        ),
                                    ));?>
                    
                   <input type="hidden" name="token" class="col-xs-10 col-sm-5" value="<?php echo Yii::app()->user->token ?>"/>
                <input type="hidden" name="cheque_data" value="<?php echo $cheque_data; ?>"/>

                <div class="form-group">
                    <label class="col-sm-3 control-label no-padding-right" for="form-field-1"> Enter Otp  </label>

                    <div class="col-sm-9">
                        <input type="text" name="otp" class="col-xs-10 col-sm-5" placeholder="OTP"/>
                    </div>
                </div>
<!--                <img src='data:image/jpeg;base64,<?php //echo $cheque ?>'alt='Red dot' />-->
                
                <div class="form-group">

                </div>
                <div class="form-group">

                </div>
                <div class="form-group">

                </div>
                <div class="clearfix"></div>
                <div class="clearfix form-actions">
<!--                    <div class="col-md-offset-3 col-md-9">
                        <a class="btn btn-info" href="<?php //echo Yii::app()->createUrl('site/downloadfiles', array('path' => $url,'name'=>$name)) ?>">
                            <i class="ace-icon fa fa-check bigger-110"></i>
                            Download
                        </a>

                      
                    </div>-->
                     <div class="col-md-offset-3 col-md-9">
                         <button class="btn btn-info" type="submit">
                            <i class="ace-icon fa fa-check bigger-110"></i>
                            Submit
                        </button>

                      
                    </div>
                </div>
               <?php $this->endWidget();?>








                <!-- PAGE CONTENT ENDS -->
            </div><!-- /.col -->
        </div><!-- /.row -->
    </div><!-- /.page-content -->
</div>