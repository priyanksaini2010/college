<?php $this->setPageTitle("Dashboard"); ?>
<div class="main-content-inner">
    <div class="breadcrumbs ace-save-state" id="breadcrumbs">
        <ul class="breadcrumb">
            <li>
                <i class="ace-icon fa fa-home home-icon"></i>
                <a href="#">Home</a>
            </li>
            <li class="active">Generate Cheque</li>
        </ul><!-- /.breadcrumb -->

        <div class="nav-search" id="nav-search">
            <form class="form-search">
                <span class="input-icon">
                    <input type="text" placeholder="Search ..." class="nav-search-input" id="nav-search-input" autocomplete="off" />
                    <i class="ace-icon fa fa-search nav-search-icon"></i>
                </span>
            </form>
        </div><!-- /.nav-search -->
    </div>

    <div class="page-content">


        <div class="page-header">
            <h1>
                Generate Cheque

            </h1>
        </div><!-- /.page-header -->

        <div class="row">
            <div class="col-xs-12">
                <!-- PAGE CONTENT BEGINS -->


    <form id="form1">
        <input type='file' id="img" />
        <img id="preview" src="" style="display:none" />
    </form>





<div class="widget-body" style="display:none" id="show_chque_info">
                                        <div class="widget-main">
                                           <div class="profile-user-info profile-user-info-striped">
                                               												<div class="profile-info-row">
													<div class="profile-info-name"> Payee </div>

													<div class="profile-info-value">
														<span class="editable editable-click" id="payee"></span>
													</div>
												</div>
                                               												<div class="profile-info-row">
													<div class="profile-info-name"> Amount </div>

													<div class="profile-info-value">
														<span class="editable editable-click" id="amount">INR 0</span>
													</div>
												</div>
                                               												<div class="profile-info-row">
													<div class="profile-info-name"> Date </div>

													<div class="profile-info-value">
														<span class="editable editable-click" id="issue_date">INR 0</span>
													</div>
												</div>
                                               				

											

											</div>
                                        </div>
                                    </div>
                
                  <div class="clearfix"></div>
                  <div class="clearfix form-actions" id="deposit_cheque_btn" style="display: none">
                    <div class="col-md-offset-3 col-md-9">
                        <a class="btn btn-info" href="<?php echo Yii::app()->createUrl('site/depositSuccess')?>">
                            <i class="ace-icon fa fa-check bigger-110"></i>
                            Deposit
                        </a>

                      
                    </div>
                   
                </div>


                <!-- PAGE CONTENT ENDS -->
            </div><!-- /.col -->
        </div><!-- /.row -->
    </div><!-- /.page-content -->
</div>
<script>
      
    </script>