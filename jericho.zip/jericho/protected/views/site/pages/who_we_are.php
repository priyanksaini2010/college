<?php $this->setPageTitle('Who we are'); ?>
<section class="banner_area who_we_are">
    <div class="container">
        <h2>You are always a student, never a master. You have to keep moving forward</h2>
        <span>- Conrad Hall</span>
    </div>
</section> 
<?php 
    $data  = ContentJson::model()->findByAttributes(array("page"=>"who_we_are"));
    echo $data->data;
?>  
