<section class="banner_area declimier">
    <div class="container">
        <h2>Our actions are in sync with the intention of nurturing young minds. If you don’t trust us don’t use our site. </h2>
    </div>
</section> 
<?php $this->setPageTitle('Disclaimer'); ?>
<?php $data  = ContentJson::model()->findByAttributes(array("page"=>"declimier"));
    echo $data->data;
?>