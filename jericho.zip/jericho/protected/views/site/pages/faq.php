<section class="banner_area faq">
    <div class="container">
        <h2>You are always a student, never a master. You have to keep moving forward</h2>
        <span>- Conrad Hall</span>
    </div>
</section>  
<?php 
$faqs = Faq::model()->findAll();
?>
<section class="bielf_container">
    <div class="container">
        <div class="main_heading faq_hdng">
            <h4>FAQ’s</h4>
            <h3>Frequently Asked Questions</h3>
        </div>
        <p class="blf_text">Expand the following drop-downs for answers to frequently asked questions.</p> 
        <div class="faq_Container">
            <ul id="accordion1" class="accordion">
                <?php foreach($faqs as $faq){?>
                <li>
                    <div class="link"><?php echo $faq->question?>? <span class="minus_icon"></span></div>
                    <ul class="submenu">
                        <p><?php echo $faq->answer;?></p>
                    </ul>
                </li>
                <?php }?>
            </ul>
            <div class="usefull_Faq margin_bottom_45">
                <span>Was this helpful?</span>
                <ul class="list-inline list-unstyled">
                    <li><a href="<?php echo Yii::app()->createUrl("FaqAnalysis/create",array("type"=>1))?>">Yes</a></li>
                    <li><a href="<?php echo Yii::app()->createUrl("FaqAnalysis/create",array("type"=>2))?>">No</a></li>
                </ul>
            </div>
        </div>
    </div>
</section>