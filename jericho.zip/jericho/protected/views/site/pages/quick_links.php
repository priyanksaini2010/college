<section class="banner_area quick_link">
    <div class="container">
        <h2>You are always a student, never a master. You have to keep moving forward</h2>
        <span>- Conrad Hall</span>
    </div>
</section> 
<?php $this->setPageTitle('Quick Links'); ?>
<?php $data  = ContentJson::model()->findByAttributes(array("page"=>"quick_links"));
    echo $data->data;
?>