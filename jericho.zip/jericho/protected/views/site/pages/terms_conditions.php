<section class="banner_area term_conditions">
    <div class="container">
        <h2>If your motives are good, our terms and conditions are easy to comply</h2>
    </div>
</section> 
<?php $this->setPageTitle('Term And Conditions'); ?>
<?php $data  = ContentJson::model()->findByAttributes(array("page"=>"terms_conditions"));
    echo $data->data;
?>
