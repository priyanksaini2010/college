<section class="banner_area our_bielf">
    <div class="container">
        <h2>You are always a student, never a master. You have to keep moving forward</h2>
        <span>- Conrad Hall</span>
    </div>
</section> 
<?php $this->setPageTitle('Our Belief');?>
<?php $data  = ContentJson::model()->findByAttributes(array("page"=>"our_bielf"));
    echo $data->data;
?>