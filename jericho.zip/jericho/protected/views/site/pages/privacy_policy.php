<section class="banner_area privacy_policy">
    <div class="container">
        <h2>Your life is private, our site is private</h2>
    </div>
</section> 
<?php $this->setPageTitle('Privacy Policy'); ?>
<?php $data  = ContentJson::model()->findByAttributes(array("page"=>"privacy_policy"));
    echo $data->data;
?>