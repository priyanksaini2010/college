<section class="banner_area copyright_notice">
    <div class="container">
        <h2>You were born an orignal, not downloaded -don't diacopy</h2>
        <span>- Conrad Hall</span>
    </div>
</section> 
<?php $this->setPageTitle('Copyright'); ?>
<?php $data  = ContentJson::model()->findByAttributes(array("page"=>"copyright_notice"));
    echo $data->data;
?>