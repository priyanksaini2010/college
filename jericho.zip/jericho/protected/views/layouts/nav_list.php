<ul class="nav nav-list">
    <li class="active">
        <a href="<?php echo Yii::app()->createUrl("site/dashboard")?>">
            <i class="menu-icon fa fa-tachometer"></i>
            <span class="menu-text"> Account  </span>
        </a>

        <b class="arrow"></b>
    </li>

    <li class="">
        <a href="#" class="dropdown-toggle">
            <i class="menu-icon fa fa-desktop"></i>
            <span class="menu-text">
                Transact
            </span>

            <b class="arrow fa fa-angle-down"></b>
        </a>

        <b class="arrow"></b>

        <ul class="submenu">
            <li class="">
                <a href="#" class="dropdown-toggle">
                    <i class="menu-icon fa fa-caret-right"></i>

                    Open Fixed Deposit
                    <b class="arrow fa fa-angle-down"></b>
                </a>

     
            </li>

            <li class="">
                <a href="#">
                    <i class="menu-icon fa fa-caret-right"></i>
                    Open Recurring Deposit
                </a>

                <b class="arrow"></b>
            </li>

            <li class="">
                <a href="#">
                    <i class="menu-icon fa fa-caret-right"></i>
                    Open New FCNR Deposit
                </a>

                <b class="arrow"></b>
            </li>

        </ul>
    </li>
       <li class="">
        <a href="<?php echo Yii::app()->createUrl("site/chequeGenerate")?>">
            <i class="menu-icon fa fa-check-circle"></i>
            <span class="menu-text"> Cheque Generate  </span>            
        </a>

     
    </li>
      <li class="">
        <a href="<?php echo Yii::app()->createUrl('site/depositCheque');?>" >
            <i class="menu-icon fa fa-download"></i>
            <span class="menu-text"> Cheque Deposit  </span>           
        </a>

     
    </li>

 
       <li class="">
        <a href="#" class="dropdown-toggle">
            <i class="menu-icon fa  fa-envelope-o"></i>
            <span class="menu-text"> Enquire </span>

            <b class="arrow fa fa-angle-down"></b>
        </a>

        <b class="arrow"></b>

        <ul class="submenu">
            <li class="">
                <a href="#">
                    <i class="menu-icon fa fa-caret-right"></i>
                    View/Download Account Statement
                </a>

                <b class="arrow"></b>
            </li>

            <li class="">
                <a href="#">
                    <i class="menu-icon fa fa-caret-right"></i>
                    TDS Enquiry
                </a>

                <b class="arrow"></b>
            </li>
        </ul>
    </li>

    <li class="">
        <a href="#" class="dropdown-toggle">
            <i class="menu-icon glyphicon glyphicon-tags"></i>
            <span class="menu-text"> Requests </span>

            <b class="arrow fa fa-angle-down"></b>
        </a>

        <b class="arrow"></b>

        <ul class="submenu">
            <li class="">
                <a href="#">
                    <i class="menu-icon fa fa-caret-right"></i>
                    Confirm KYC Details
                </a>

                <b class="arrow"></b>
            </li>

            <li class="">
                <a href="#">
                    <i class="menu-icon fa fa-caret-right"></i>
                    Update Extended KYC
                </a>

                <b class="arrow"></b>
            </li>

            <li class="">
                <a href="#">
                    <i class="menu-icon fa fa-caret-right"></i>
                    Demand Draft    
                </a>

                <b class="arrow"></b>
            </li>

            <li class="">
                <a href="#">
                    <i class="menu-icon fa fa-caret-right"></i>
                    View/Update PAN Number
                </a>

                <b class="arrow"></b>
            </li>

            <li class="">
                <a href="#">
                    <i class="menu-icon fa fa-caret-right"></i>
                     View/Update Aadhaar Number
                </a>

                <b class="arrow"></b>
            </li>
        </ul>
    </li>

   

  

    
</ul><!-- /.nav-list -->